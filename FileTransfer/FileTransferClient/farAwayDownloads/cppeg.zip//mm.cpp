using namespace std;
#include<iostream>
class Matrix
{
static int x;
int **matrix;
int rows;
int columns; 
Matrix *result;
public:

Matrix()
{
this->rows=0;
this->columns=0;
this->matrix=NULL;
this->result=NULL;
}


Matrix(int rows,int columns)
{
this->rows=rows;
this->columns=columns;
this->matrix=NULL;
this->result=NULL;
this->setData();
}



Matrix(const Matrix &m)
{
this->rows=m.rows;
 mthis->columns=m.columns;
this->result=m.result;
this->matrix=m.matrix;
}



void setData()
{
int i,j;
matrix=new int*[rows];
for(i=0;i<rows;i++) matrix[i]=new int[columns];
for(i=0;i<rows;i++)
{
for(j=0;j<columns;j++)
{
cout<<"Enetr data for matrix"<<x<<": matrix["<<i<<"]["<<j<<"]: ";
cin>>matrix[i][j];
}
cout<<endl;
}
x++;
}



Matrix & operator+(Matrix &m)
{
int i,j;
if(this->rows!=m.rows && this->columns!=m.columns)
{
cout<<"Cant add two matrices of different number of rows and column"<<endl;
return *result;
}
result=new Matrix();
result->rows=m.rows;
result->columns=m.columns;
result->matrix=new int*[this->rows];
for(i=0;i<this->rows;i++) result->matrix[i]=new int[this->columns];
for(i=0;i<this->rows;i++)
{
for(j=0;j<this->columns;j++)
{
this->result->matrix[i][j]=this->matrix[i][j]+m.matrix[i][j]; 
}
}
return *result;
}



Matrix & operator-(Matrix &m)
{
int i,j;
if(this->rows!=m.rows && this->columns!=m.columns)
{
cout<<"Cant multiply two matrices of different number of rows and column"<<endl;
return *result;
}
result=new Matrix();
result->rows=m.rows;
result->columns=m.columns;
result->matrix=new int*[this->rows];
for(i=0;i<this->rows;i++) result->matrix[i]=new int[this->columns];
for(i=0;i<this->rows;i++)
{
for(j=0;j<this->columns;j++)
{
result->matrix[i][j]=this->matrix[i][j]-m.matrix[i][j]; 
}
}
return *result;
}


Matrix operator*(Matrix &m)
{
int i,j,k,sum=0;
if(this->rows!=m.columns && this->columns!=m.rows)
{
cout<<"Cant add two matrices of different number of rows and column"<<endl;
return *result;
}
result=new Matrix();
result->rows=m.rows;
result->columns=m.columns;
result->matrix=new int*[this->rows];
for(i=0;i<this->rows;i++) result->matrix[i]=new int[this->columns];
for(i=0;i<this->rows;i++)
{
for(j=0;j<this->rows;j++)
{
for(k=0;k<this->columns;k++)
{
sum+=(this->matrix[i][k])*(m.matrix[k][j]);
}
result->matrix[i][j]=sum;
sum=0;
}
}
return *result;
}


Matrix  operator/(Matrix &m)
{
int i,j;
if(this->rows!=m.rows && this->columns!=m.columns)
{
cout<<"Cant add two matrices of different number of rows and column"<<endl;
return *result;
}
result=new Matrix();
result->rows=m.rows;
result->columns=m.columns;
result->matrix=new int*[this->rows];
for(i=0;i<this->rows;i++) result->matrix[i]=new int[this->columns];
for(i=0;i<this->rows;i++)
{
for(j=0;j<this->columns;j++)
{
this->result->matrix[i][j]=this->matrix[i][j]/m.matrix[i][j]; 
}
}
return *result;
}



Matrix & operator=(Matrix m)
{
int i,j;
this->rows=m.rows;
this->columns=m.columns;
this->matrix=new int*[this->rows];
for(i=0;i<this->rows;i++) this->matrix[i]=new int[this->columns];
cout<<"Result:"<<endl;
for(i=0;i<this->rows;i++)
{
for(j=0;j<this->columns;j++)
{
this->matrix[i][j]=m.matrix[i][j];
cout<<this->matrix[i][j]<<" "; 
}
cout<<endl;
}
return *this;
}
};
int Matrix:: x=1;
int main()
{
Matrix m1(3,3),m2(3,3);
Matrix m3;
m3=m1+m2;
m3=m1-m2;
m3=m1*m2;
m3=m1/m2;
return 0;
}