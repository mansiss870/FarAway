using namespace std;
#include<iostream>
#include<vector>
int main()
{
vector<int> vect(10);
for(int i=0;i<=9;i++)
{
cout<<vect[i]<<" "<<endl;
}
return 0;
}