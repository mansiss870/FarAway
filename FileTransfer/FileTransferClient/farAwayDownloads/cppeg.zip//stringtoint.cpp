using namespace std;
#include<iostream>
void stringToInt(int &data)
{
char s[10];
char c;
cout<<"Enter a String"<<endl;
fgets(s,10,stdin);
int x=0;
int y=1;
for(int i=9;i>=0;--i)
{
c=s[i];
if(c>=48 && c<=57)
{
x=x+((c-48)*y);
y=y*10;
}
}
data=x;
}
int main()
{
int x;
stringToInt(x);
cout<<x<<endl;
}