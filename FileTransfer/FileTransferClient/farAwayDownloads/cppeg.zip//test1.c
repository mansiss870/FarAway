#include<stdio.h>
int main()
{
int x,y,z,l,m,n;
y=8;
z=2;
x=x/y(y+y);
printf("%d",x);
return 0;
}