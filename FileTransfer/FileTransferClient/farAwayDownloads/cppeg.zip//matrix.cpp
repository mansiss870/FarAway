using namespace std;
#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
class Matrix
{
private:
int numberOfRows;
int numberOfColumns;
int size;
int *matrix;
Matrix(const Matrix &other);
Matrix(int,int,int*);
public:
void printMatrix();
static Matrix * createMatrix(int numberOfRows,int numberOfColumns)
{
int *x;
x=(int*)malloc(sizeof(int)*(numberOfRows*numberOfColumns));
if(x==NULL) return NULL;
return new Matrix(numberOfRows,numberOfColumns,x);
}
};
Matrix::Matrix(int numberOfRows,int numberOfColumns,int *matrix)
{
this->numberOfRows=numberOfRows;
this->numberOfColumns=numberOfColumns;
this->size=numberOfRows*numberOfColumns;
this->matrix=matrix;
}
void Matrix::printMatrix()
{
int *j;
for(int r=0;r<this->numberOfRows;r++)
{
for(int c=0;c<this->numberOfColumns;c++)
{
j=(matrix+(r*numberOfColumns))+c;
printf("%10d",*j);
}
printf("\n");
}
}
int main()
{
Matrix *m=Matrix::createMatrix(3,6);
m->printMatrix();
return 0;
}