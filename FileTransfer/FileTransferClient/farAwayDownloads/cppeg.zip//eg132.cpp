using namespace std;
include<iostream>
class Bulb
{
private:
int w;
public:

}