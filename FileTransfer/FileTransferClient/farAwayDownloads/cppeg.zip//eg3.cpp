#include<iostream>
using namespace std;
class bbb
{
static int x;
int vode;
int k;
public:
int getCode()
{
cout<<vode<<","<<k<<endl;
vode=x;
cout<<vode<<endl;
x++;
}
};
int bbb::x=2001;
int main()
{
bbb b;
b.getCode();
}