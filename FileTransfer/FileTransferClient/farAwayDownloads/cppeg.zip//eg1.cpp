using namespace std;
#include<iostream>
int main()
{
int r,c;
cout<<"Enter number of raws:"<<endl;
cin>>r;
cout<<"Enter number of columns:"<<endl;
cin>>c;
int **raw;
raw=new int*[r];
for(int i=0;i<c;i++)
{
raw[i]=new int[c];
}
int n=0;
for(int i=0;i<r;i++)
{
for(int j=0;j<c;j++)
{
raw[i][j]=n;
n++;
cout<<raw[i][j];
}
cout<<endl;
}
return 0;
}